﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Logic.Entities
{
    public class ID
    {
        public int IDnr;
    }
}
