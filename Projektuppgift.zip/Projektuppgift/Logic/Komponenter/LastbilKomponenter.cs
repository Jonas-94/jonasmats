﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Logic.Entities
{
    public class LastbilKomponenter
    {
        public int Däck { get; set; }
        public int Motorer { get; set; }
        public int Vindrutor { get; set; }
        public int Bromsar { get; set; }
        public int Karosser { get; set; }
    }
}
